package nada;

import java.lang.reflect.Array;
import java.util.ArrayList;

class Client extends Person {

    Address address;
    Phone phone;
    String userName;
    String password;
    private int clientID;

    public Client(Address address, Phone phone, String userName, String password, int clientID) {
        this.address = address;
        this.phone = phone;
        this.userName = userName;
        this.password = password;
        this.clientID = clientID;
    }


    public static ArrayList<clientDataCollection> Client(int clientID, String userName, String password) {
        this.clientID = clientID;
        this.userName = userName;
        if (password.length() < 8)
            System.out.println("Password cannot be less than 8 characters.");
        else
            this.password = password;
        return clientDataCollection.add(clientID, userName, password);

    }

    public void setClientID(int id) {
        this.clientID = id;
    }

}
