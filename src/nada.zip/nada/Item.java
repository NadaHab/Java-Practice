package nada;

public class Item {
    int serialNumber;
    String name;
    String description;
    double weight;
    double price;

    public Item(int serialNumber, String name, String description, double weight, double price) {
        this.serialNumber = serialNumber;
        this.name = name;
        this.description = description;
        this.weight = weight;
        this.price = price;
    }


}
