package nada;

public class  StoreDataCollection extends Item{

    public StoreDataCollection(int serialNumber, String name, String description, double weight, double price) {
        super(serialNumber, name, description, weight, price);
    }
}
