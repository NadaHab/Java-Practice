package nada;

import java.util.Objects;

class Person {
    int SIN;
    String firstName;
    String lastName;
//     private String genome;

    public Person() {
    }

    Person(int SIN, String firstName, String lastName) {
        if (this.equals(SIN)) {
            System.out.println("Cannot have duplicate Social Security Numer");
         else
            this.SIN = SIN;
        }
        if ((this.firstName.length()) < 20)
            this.firstName = firstName;
        else
            System.out.println("First name cannot be more than 20 characters.");
        if ((this.lastName.length()) < 20)
            this.lastName = lastName;
        else
            System.out.println("Last name cannot be more than 20 characters.");
    }


}
