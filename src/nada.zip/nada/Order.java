package nada;

import java.util.ArrayList;

public class Order {
    int orderId;
    Client client;
    ArrayList<Item> items;
    Address shippingAddress;
    double totalPrice;

    public Order(int orderId, Client client, ArrayList<Item> items, Address shippingAddress, double totalPrice) {
        this.orderId = orderId;
        this.client = client;
        this.items = items;
        this.shippingAddress = shippingAddress;
        this.totalPrice = totalPrice;
    }
}
