package nada;

import java.util.Collections;

public class Main {

    public static void main(String[] args) {
        ArrayList<Client> ClientArrayList= new ArrayList<>();
        ArrayList<Item> ClientArrayList= new ArrayList<>();
        ClientDataCollection("John Abbott", 111, "514 457 5036", "Montreal", "Canada Quebec",
                "21 275 Rue Lakeshore Road", "Saint Anne de Bellevue", "QC", "H9X 3L9");
        Collections.sort(carArrayList);
        showDataCollection();
        storeinitializer();
        Collections.sort(carArrayList);

    }


    private static void showDataCollection() {
        System.out.println("\n\nDataCollection state: \n" + clientDataCollection + "\n");
    }
    public static storeinitializer(){
        
    }
}
