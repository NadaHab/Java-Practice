package nada;

public class Phone {
    int countryCode;
    int areaCode;
    int prefix;
    int lineNumber;

  public static UpdatePhoneNumer(int phoneNumber){
      this.lineNumber=phoneNumber;
  }
}
